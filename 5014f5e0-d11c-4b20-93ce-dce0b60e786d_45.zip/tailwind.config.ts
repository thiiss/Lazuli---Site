
import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        'sans': ['Onest', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        'onest': ['Onest', 'sans-serif'],
      },
      colors: {
        'lazuli': {
          'primary': '#0027A6',    // Cor principal do logo
          'secondary': '#0024BA',  // Cor secundária do logo
          'tertiary': '#0130CA',   // Cor terciária do logo
          'dark': '#1F317B',       // Cor auxiliar escura
          'gold': '#B98A01',       // Cor auxiliar dourada
          'gray-dark': '#282B32',  // Cor auxiliar cinza escuro
          'gray-light': '#F2F7FD', // Cor auxiliar cinza claro
        }
      }
    },
  },
  plugins: [],
}

export default config
