
import { RouteObject } from 'react-router-dom';
import HomePage from '../pages/home/page';
import ZulaPage from '../pages/zula/page';
import FiraPage from '../pages/fira/page';
import NotFound from '../pages/NotFound';

const routes: RouteObject[] = [
  {
    path: '/',
    element: <HomePage />,
  },
  {
    path: '/zula',
    element: <ZulaPage />,
  },
  {
    path: '/fira',
    element: <FiraPage />,
  },
  {
    path: '*',
    element: <NotFound />,
  },
];

export default routes;
