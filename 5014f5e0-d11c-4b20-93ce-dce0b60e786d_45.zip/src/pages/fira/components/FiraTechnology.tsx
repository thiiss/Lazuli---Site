
export default function FiraTechnology() {
  const technologies = [
    {
      category: 'Hardware Principal',
      icon: 'ri-cpu-line',
      color: 'bg-orange-500',
      items: [
        { name: 'Raspberry Pi 4', description: '8GB RAM, processamento ARM Cortex-A72' },
        { name: 'Dual Webcam System', description: 'Duas câmeras 1080p com autofoco' },
        { name: 'Armazenamento SSD', description: '256GB para dados e modelos ML' },
        { name: 'Conectividade', description: 'Wi-Fi 6, Ethernet Gigabit, USB 3.0' }
      ]
    },
    {
      category: 'Visão Computacional',
      icon: 'ri-eye-line',
      color: 'bg-blue-500',
      items: [
        { name: 'OpenCV', description: 'Processamento de imagem avançado' },
        { name: 'TensorFlow Lite', description: 'Modelos ML otimizados para edge' },
        { name: 'YOLO v8', description: 'Detecção de objetos em tempo real' },
        { name: 'Image Segmentation', description: 'Análise pixel-level de defeitos' }
      ]
    },
    {
      category: 'Software e IA',
      icon: 'ri-brain-line',
      color: 'bg-purple-500',
      items: [
        { name: 'Python', description: 'Linguagem principal do sistema' },
        { name: 'Machine Learning', description: 'Algoritmos de classificação' },
        { name: 'Real-time Processing', description: 'Processamento em tempo real' },
        { name: 'Edge Computing', description: 'Computação local sem latência' }
      ]
    },
    {
      category: 'Integração Industrial',
      icon: 'ri-settings-line',
      color: 'bg-green-500',
      items: [
        { name: 'Modbus TCP/IP', description: 'Comunicação industrial padrão' },
        { name: 'REST API', description: 'Integração com sistemas ERP/MES' },
        { name: 'MQTT Protocol', description: 'IoT e telemetria em tempo real' },
        { name: 'OPC UA', description: 'Padrão Industry 4.0' }
      ]
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Tecnologia <span className="text-orange-600">de Ponta</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Combinação perfeita de hardware robusto e software inteligente para inspeção de qualidade
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {technologies.map((tech, index) => (
            <div key={index} className="bg-gray-50 rounded-2xl p-8">
              <div className="flex items-center mb-6">
                <div className={`w-12 h-12 ${tech.color} rounded-lg flex items-center justify-center mr-4`}>
                  <i className={`${tech.icon} text-xl text-white`}></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900">{tech.category}</h3>
              </div>
              
              <div className="space-y-4">
                {tech.items.map((item, idx) => (
                  <div key={idx} className="bg-white rounded-lg p-4 shadow-sm">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-1">{item.name}</h4>
                        <p className="text-sm text-gray-600">{item.description}</p>
                      </div>
                      <i className="ri-check-line text-green-500 text-lg"></i>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Hardware Showcase */}
        <div className="mt-16 bg-gradient-to-r from-gray-900 to-gray-800 rounded-2xl p-8 text-white">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-bold mb-6">Sistema Dual de Webcams</h3>
              <p className="text-xl text-gray-300 mb-8">
                Configuração inovadora com duas webcams sincronizadas que capturam diferentes ângulos 
                simultaneamente, garantindo inspeção completa e detecção de defeitos em áreas ocultas.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white/10 rounded-lg p-4">
                  <i className="ri-camera-line text-3xl text-orange-400 mb-2"></i>
                  <h4 className="font-semibold mb-2">Câmera Principal</h4>
                  <p className="text-sm text-gray-300">Visão frontal com foco em detalhes superficiais</p>
                </div>
                <div className="bg-white/10 rounded-lg p-4">
                  <i className="ri-camera-2-line text-3xl text-blue-400 mb-2"></i>
                  <h4 className="font-semibold mb-2">Câmera Auxiliar</h4>
                  <p className="text-sm text-gray-300">Ângulo lateral para inspeção dimensional</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white/5 rounded-xl p-6">
              <h4 className="text-xl font-bold mb-4">Especificações das Câmeras</h4>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-300">Resolução</span>
                  <span className="font-semibold">1920x1080 @ 30fps</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Sensor</span>
                  <span className="font-semibold">CMOS 1/2.9"</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Foco</span>
                  <span className="font-semibold">Autofoco automático</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Campo de Visão</span>
                  <span className="font-semibold">78° diagonal</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Conectividade</span>
                  <span className="font-semibold">USB 3.0</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
