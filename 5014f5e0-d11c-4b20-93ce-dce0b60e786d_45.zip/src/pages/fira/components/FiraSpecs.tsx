
import { useTranslation } from 'react-i18next'

export default function FiraSpecs() {
  const { t } = useTranslation('fira')

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Especificações Técnicas */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Especificações Técnicas
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Tecnologia de ponta para máxima precisão e confiabilidade em ambientes industriais
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
          <div>
            <img
              src="https://readdy.ai/api/search-image?query=Advanced%20industrial%20camera%20system%20with%20high-tech%20sensors%20and%20precision%20components%2C%20modern%20manufacturing%20equipment%2C%20clean%20white%20background%2C%20professional%20product%20photography%2C%20detailed%20technical%20view&width=600&height=400&seq=fira-tech-specs&orientation=landscape"
              alt="Especificações técnicas do Fira"
              className="w-full h-96 object-cover rounded-2xl shadow-lg"
            />
          </div>
          <div className="space-y-8">
            <div className="bg-white p-6 rounded-xl shadow-md">
              <div className="flex items-center mb-4">
                <i className="ri-camera-line text-3xl text-orange-600 mr-4"></i>
                <h3 className="text-xl font-bold text-gray-900">Sistema de Câmeras</h3>
              </div>
              <ul className="space-y-2 text-gray-600">
                <li>• Resolução 4K Ultra HD</li>
                <li>• Taxa de captura: 60 FPS</li>
                <li>• Visão noturna infravermelha</li>
                <li>• Zoom óptico 10x</li>
              </ul>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
              <div className="flex items-center mb-4">
                <i className="ri-cpu-line text-3xl text-orange-600 mr-4"></i>
                <h3 className="text-xl font-bold text-gray-900">Processamento</h3>
              </div>
              <ul className="space-y-2 text-gray-600">
                <li>• Processador ARM Cortex-A78</li>
                <li>• 8GB RAM DDR5</li>
                <li>• Armazenamento 256GB SSD</li>
                <li>• GPU dedicada para IA</li>
              </ul>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
              <div className="flex items-center mb-4">
                <i className="ri-shield-check-line text-3xl text-orange-600 mr-4"></i>
                <h3 className="text-xl font-bold text-gray-900">Resistência</h3>
              </div>
              <ul className="space-y-2 text-gray-600">
                <li>• Certificação IP67</li>
                <li>• Temperatura: -20°C a 60°C</li>
                <li>• Resistente a vibração</li>
                <li>• Proteção contra poeira</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Comparativo de Performance */}
        <div className="bg-white rounded-2xl p-8 shadow-lg">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              Performance Comparativa
            </h3>
            <p className="text-xl text-gray-600">
              Veja como o Fira supera as soluções tradicionais
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b-2 border-gray-200">
                  <th className="text-left py-4 px-6 font-bold text-gray-900">
                    Característica
                  </th>
                  <th className="text-center py-4 px-6 font-bold text-orange-600">
                    Fira
                  </th>
                  <th className="text-center py-4 px-6 font-bold text-gray-500">
                    Solução Tradicional
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                <tr>
                  <td className="py-4 px-6 font-medium text-gray-900">
                    Precisão de Detecção
                  </td>
                  <td className="py-4 px-6 text-center">
                    <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full font-bold">
                      99.8%
                    </span>
                  </td>
                  <td className="py-4 px-6 text-center">
                    <span className="bg-red-100 text-red-800 px-3 py-1 rounded-full">
                      85%
                    </span>
                  </td>
                </tr>
                <tr>
                  <td className="py-4 px-6 font-medium text-gray-900">
                    Tempo de Resposta
                  </td>
                  <td className="py-4 px-6 text-center">
                    {/* Escape the "<" character to avoid JSX parsing errors */}
                    <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full font-bold">
                      {'< 100ms'}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-center">
                    <span className="bg-red-100 text-red-800 px-3 py-1 rounded-full">
                      2-5s
                    </span>
                  </td>
                </tr>
                <tr>
                  <td className="py-4 px-6 font-medium text-gray-900">
                    Falsos Positivos
                  </td>
                  <td className="py-4 px-6 text-center">
                    {/* Escape the "<" character here as well */}
                    <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full font-bold">
                      {'< 0.1%'}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-center">
                    <span className="bg-red-100 text-red-800 px-3 py-1 rounded-full">
                      15-20%
                    </span>
                  </td>
                </tr>
                <tr>
                  <td className="py-4 px-6 font-medium text-gray-900">
                    Custo de Manutenção
                  </td>
                  <td className="py-4 px-6 text-center">
                    <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full font-bold">
                      Baixo
                    </span>
                  </td>
                  <td className="py-4 px-6 text-center">
                    <span className="bg-red-100 text-red-800 px-3 py-1 rounded-full">
                      Alto
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  )
}
