
export default function FiraFeatures() {
  const features = [
    {
      icon: 'ri-camera-2-line',
      title: 'Sistema Dual de Webcams',
      description: 'Duas webcams de alta resolução trabalham em conjunto para capturar múltiplos ângulos e garantir inspeção completa de cada produto.',
      benefits: ['Cobertura 360° do produto', 'Detecção de defeitos ocultos', 'Redundância para maior confiabilidade']
    },
    {
      icon: 'ri-cpu-line',
      title: 'Raspberry Pi 4 de Alta Performance',
      description: 'Hardware otimizado com processamento local que garante resposta em tempo real e operação contínua sem dependência de conectividade.',
      benefits: ['Processamento local rápido', 'Operação offline', 'Baixo consumo energético']
    },
    {
      icon: 'ri-eye-line',
      title: 'Visão Computacional Avançada',
      description: 'Algoritmos de machine learning treinados especificamente para detectar defeitos, variações de cor, dimensões e acabamento.',
      benefits: ['Precisão de 99.5%', 'Aprendizado contínuo', 'Detecção de múltiplos tipos de defeito']
    },
    {
      icon: 'ri-dashboard-line',
      title: 'Interface de Monitoramento',
      description: 'Dashboard intuitivo que exibe estatísticas em tempo real, histórico de inspeções e relatórios detalhados de qualidade.',
      benefits: ['Visualização em tempo real', 'Relatórios automáticos', 'Alertas personalizáveis']
    },
    {
      icon: 'ri-settings-3-line',
      title: 'Configuração Flexível',
      description: 'Sistema adaptável que permite configurar parâmetros de inspeção específicos para diferentes tipos de produtos e processos.',
      benefits: ['Múltiplos perfis de produto', 'Ajustes de sensibilidade', 'Calibração automática']
    },
    {
      icon: 'ri-bar-chart-line',
      title: 'Análise Estatística Avançada',
      description: 'Coleta e análise de dados de qualidade para identificar tendências, padrões e oportunidades de melhoria contínua.',
      benefits: ['Controle estatístico de processo', 'Previsão de problemas', 'Otimização contínua']
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Recursos <span className="text-orange-600">Inovadores</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Tecnologia de ponta em visão computacional para inspeção de qualidade automatizada
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="w-16 h-16 bg-orange-100 rounded-xl flex items-center justify-center mb-6">
                <i className={`${feature.icon} text-2xl text-orange-600`}></i>
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-4">{feature.title}</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">{feature.description}</p>
              
              <div className="space-y-2">
                {feature.benefits.map((benefit, idx) => (
                  <div key={idx} className="flex items-center">
                    <i className="ri-check-line text-green-500 mr-2"></i>
                    <span className="text-sm text-gray-600">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Removed Results Section */}
      </div>
    </section>
  );
}
