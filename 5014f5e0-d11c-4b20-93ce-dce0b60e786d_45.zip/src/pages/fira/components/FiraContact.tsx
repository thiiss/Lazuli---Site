
import { useState } from 'react';

export default function FiraContact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    phone: '',
    industry: '',
    productionVolume: '',
    currentQualityProcess: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const formDataToSend = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        formDataToSend.append(key, value);
      });

      const response = await fetch('https://readdy.ai/api/form/d459fvfdee34hhmbeeog', {
        method: 'POST',
        body: formDataToSend
      });

      if (response.ok) {
        setSubmitStatus('success');
        setFormData({
          name: '',
          email: '',
          company: '',
          phone: '',
          industry: '',
          productionVolume: '',
          currentQualityProcess: '',
          message: ''
        });
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-orange-50 to-red-100">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Análise Técnica Industrial - Fira
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Revolucione seu controle de qualidade com visão computacional avançada. 
              Nossa equipe técnica fará uma análise personalizada do seu processo produtivo.
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-xl p-8">
            <form id="fira-contact-form" data-readdy-form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                    Nome Completo *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm"
                    placeholder="Seu nome completo"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    E-mail Corporativo *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm"
                    placeholder="seu.email@empresa.com"
                  />
                </div>

                <div>
                  <label htmlFor="company" className="block text-sm font-medium text-gray-700 mb-2">
                    Empresa *
                  </label>
                  <input
                    type="text"
                    id="company"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm"
                    placeholder="Nome da sua empresa"
                  />
                </div>

                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                    Telefone
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm"
                    placeholder="(11) 99999-9999"
                  />
                </div>

                <div>
                  <label htmlFor="industry" className="block text-sm font-medium text-gray-700 mb-2">
                    Setor Industrial *
                  </label>
                  <select
                    id="industry"
                    name="industry"
                    value={formData.industry}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm pr-8"
                  >
                    <option value="">Selecione seu setor</option>
                    <option value="automotivo">Automotivo</option>
                    <option value="eletronicos">Eletrônicos</option>
                    <option value="alimenticio">Alimentício</option>
                    <option value="farmaceutico">Farmacêutico</option>
                    <option value="textil">Têxtil</option>
                    <option value="metalurgico">Metalúrgico</option>
                    <option value="plasticos">Plásticos</option>
                    <option value="outros">Outros</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="productionVolume" className="block text-sm font-medium text-gray-700 mb-2">
                    Volume de Produção *
                  </label>
                  <select
                    id="productionVolume"
                    name="productionVolume"
                    value={formData.productionVolume}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm pr-8"
                  >
                    <option value="">Selecione o volume</option>
                    <option value="baixo">Baixo (até 1.000 unidades/mês)</option>
                    <option value="medio">Médio (1.000 - 10.000 unidades/mês)</option>
                    <option value="alto">Alto (10.000 - 100.000 unidades/mês)</option>
                    <option value="muito-alto">Muito Alto (mais de 100.000 unidades/mês)</option>
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="currentQualityProcess" className="block text-sm font-medium text-gray-700 mb-2">
                  Processo Atual de Qualidade
                </label>
                <input
                  type="text"
                  id="currentQualityProcess"
                  name="currentQualityProcess"
                  value={formData.currentQualityProcess}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm"
                  placeholder="Ex: Inspeção manual, controle estatístico, outros sistemas..."
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                  Desafios e Necessidades
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={4}
                  maxLength={500}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm resize-none"
                  placeholder="Descreva os principais desafios de qualidade que sua empresa enfrenta e como o Fira pode ajudar..."
                />
                <p className="text-xs text-gray-500 mt-1">
                  {formData.message.length}/500 caracteres
                </p>
              </div>

              {submitStatus === 'success' && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex">
                    <i className="ri-check-circle-fill text-green-400 text-xl mr-3"></i>
                    <div>
                      <h3 className="text-sm font-medium text-green-800">
                        Solicitação enviada com sucesso!
                      </h3>
                      <p className="text-sm text-green-700 mt-1">
                        Nossa equipe técnica entrará em contato em até 24 horas para agendar a análise.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {submitStatus === 'error' && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <div className="flex">
                    <i className="ri-error-warning-fill text-red-400 text-xl mr-3"></i>
                    <div>
                      <h3 className="text-sm font-medium text-red-800">
                        Erro ao enviar solicitação
                      </h3>
                      <p className="text-sm text-red-700 mt-1">
                        Tente novamente ou entre em contato conosco diretamente.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex justify-center">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-orange-600 hover:bg-orange-700 text-white font-semibold py-4 px-8 rounded-lg transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
                >
                  {isSubmitting ? (
                    <>
                      <i className="ri-loader-4-line animate-spin mr-2"></i>
                      Enviando...
                    </>
                  ) : (
                    <>
                      <i className="ri-microscope-fill mr-2"></i>
                      Solicitar Análise Técnica
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
