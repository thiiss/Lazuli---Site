
export default function FiraHero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('https://readdy.ai/api/search-image?query=Advanced%20computer%20vision%20quality%20inspection%20system%20with%20dual%20webcam%20setup%2C%20Raspberry%20Pi%204%20hardware%2C%20industrial%20manufacturing%20environment%2C%20automated%20quality%20control%20dashboard%2C%20real-time%20defect%20detection%20interface%2C%20modern%20factory%20setting%20with%20precision%20inspection%20equipment%2C%20high-tech%20visual%20analysis%20system%2C%20professional%20industrial%20automation&width=1920&height=1080&seq=fira-hero-bg&orientation=landscape')`
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-transparent"></div>
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-white">
            <div className="flex items-center mb-6">
              <div className="w-20 h-20 bg-white rounded-2xl flex items-center justify-center p-3 mr-6">
                <img 
                  src="https://static.readdy.ai/image/e82d699222721f850528026ac5fab295/a27f8962da4c7cb6ae7f23ee445cf09d.png" 
                  alt="Logo Fira"
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <h1 className="text-5xl font-bold mb-2">Fira</h1>
                <p className="text-2xl text-orange-300">Inspeção de Qualidade com Visão Computacional</p>
              </div>
            </div>
            
            <p className="text-xl leading-relaxed mb-8 max-w-2xl">
              Sistema revolucionário de <strong>inspeção de qualidade automatizada</strong> que utiliza 
              <strong>duas webcams e Raspberry Pi 4</strong> para detectar defeitos e garantir 
              padrões de qualidade superiores em processos industriais.
            </p>
          </div>
          
          <div className="hidden lg:block">
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
              <h3 className="text-white text-2xl font-bold mb-6">Principais Benefícios</h3>
              <div className="space-y-4">
                <div className="flex items-center text-white">
                  <i className="ri-check-line text-green-400 text-xl mr-3"></i>
                  <span>Detecção automática de defeitos em tempo real</span>
                </div>
                <div className="flex items-center text-white">
                  <i className="ri-check-line text-green-400 text-xl mr-3"></i>
                  <span>Sistema dual de webcams para precisão máxima</span>
                </div>
                <div className="flex items-center text-white">
                  <i className="ri-check-line text-green-400 text-xl mr-3"></i>
                  <span>Hardware Raspberry Pi 4 de alta performance</span>
                </div>
                <div className="flex items-center text-white">
                  <i className="ri-check-line text-green-400 text-xl mr-3"></i>
                  <span>Redução de 90% em falhas de qualidade</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}