
import FiraHero from './components/FiraHero';
import FiraFeatures from './components/FiraFeatures';
import FiraTechnology from './components/FiraTechnology';
import FiraContact from './components/FiraContact';
import Footer from '../home/components/Footer';

export default function FiraPage() {
  return (
    <div className="min-h-screen">
      <FiraHero />
      <FiraFeatures />
      <FiraTechnology />
      <FiraContact />
      <Footer />
    </div>
  );
}
