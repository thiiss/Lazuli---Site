
export default function Features() {
  const features = [
    {
      icon: 'ri-robot-line',
      title: 'Automação Inteligente',
      description: 'Elimine tarefas manuais repetitivas com nossa tecnologia de automação baseada em IA, aumentando a produtividade e reduzindo erros humanos.'
    },
    {
      icon: 'ri-eye-line',
      title: 'Visão Computacional Avançada',
      description: 'Sistemas de inspeção visual automatizada com alta precisão para controle de qualidade em tempo real na linha de produção.'
    },
    {
      icon: 'ri-dashboard-line',
      title: 'Gestão Visual de Projetos',
      description: 'Interface intuitiva com Gráficos de Gantt para monitoramento claro e eficiente do progresso de todos os seus projetos.'
    },
    {
      icon: 'ri-chat-3-line',
      title: 'Assistência por IA',
      description: 'Ágatha oferece insights estratégicos através de conversação natural, ajudando na tomada de decisões baseada em dados.'
    },
    {
      icon: 'ri-stack-line',
      title: 'Arquitetura Modular',
      description: 'Soluções escaláveis que crescem com seu negócio, permitindo personalização e adaptação às necessidades específicas.'
    },
    {
      icon: 'ri-shield-check-line',
      title: 'Controle de Qualidade',
      description: 'Detecção automática de defeitos e avarias com precisão superior, garantindo padrões de qualidade consistentes.'
    }
  ];

  return (
    <section id="recursos" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h3 className="text-4xl font-bold text-gray-900 mb-4">
            Por que Escolher a <span className="text-blue-600">Lazuli</span>?
          </h3>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Nossas soluções oferecem benefícios tangíveis que transformam a <strong>eficiência operacional</strong> e a <strong>qualidade dos processos</strong> industriais
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="group p-8 rounded-xl border border-gray-200 hover:border-blue-300 hover:shadow-lg transition-all duration-300">
              <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mb-6 group-hover:bg-blue-600 transition-colors duration-300">
                <i className={`${feature.icon} text-2xl text-blue-600 group-hover:text-white transition-colors duration-300`}></i>
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-4">{feature.title}</h4>
              <p className="text-gray-600 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}