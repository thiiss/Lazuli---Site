
export default function Technology() {
  const technologies = [
    {
      category: 'Inteligência Artificial',
      items: [
        { name: 'TensorFlow/Keras', icon: 'ri-brain-line', description: 'Deep Learning para análise preditiva' },
        { name: 'Ultralytics YOLO', icon: 'ri-eye-line', description: 'Detecção de objetos em tempo real' },
        { name: 'IA Conversacional', icon: 'ri-chat-3-line', description: 'Assistente inteligente integrado ao Zula' }
      ]
    },
    {
      category: 'Desenvolvimento',
      items: [
        { name: 'Python', icon: 'ri-code-line', description: 'Pipeline de dados e processamento' },
        { name: 'Java Spring Boot', icon: 'ri-server-line', description: 'Backend robusto e escalável' },
        { name: 'Kotlin', icon: 'ri-smartphone-line', description: 'Interface moderna e responsiva' }
      ]
    },
    {
      category: 'Visão Computacional',
      items: [
        { name: 'OpenCV', icon: 'ri-camera-line', description: 'Processamento avançado de imagens' },
        { name: 'Raspberry Pi 4', icon: 'ri-cpu-line', description: 'Processamento local de alta performance' },
        { name: 'Sistema Dual de Webcams', icon: 'ri-camera-2-line', description: 'Captura de imagens com redundância' },
        { name: 'LED Controlado', icon: 'ri-lightbulb-line', description: 'Iluminação otimizada para precisão' }
      ]
    },
    {
      category: 'Infraestrutura',
      items: [
        { name: 'MySQL', icon: 'ri-database-line', description: 'Armazenamento confiável de dados' },
        { name: 'Transmissão LAN', icon: 'ri-wifi-line', description: 'Comunicação em tempo real' },
        { name: 'Arquitetura Modular', icon: 'ri-stack-line', description: 'Escalabilidade garantida' }
      ]
    }
  ];

  return (
    <section id="tecnologia" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h3 className="text-4xl font-bold text-gray-900 mb-4">
            <span className="text-blue-600">Tecnologia</span> de Ponta
          </h3>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Utilizamos as mais avançadas tecnologias em <strong>Inteligência Artificial</strong>, <strong>Visão Computacional</strong> e desenvolvimento para entregar soluções robustas e inovadoras
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {technologies.map((tech, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-lg p-8">
              <h4 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <span className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                  <i className="ri-settings-3-line text-blue-600"></i>
                </span>
                {tech.category}
              </h4>
              <div className="space-y-4">
                {tech.items.map((item, idx) => (
                  <div key={idx} className="flex items-start p-4 rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                      <i className={`${item.icon} text-blue-600`}></i>
                    </div>
                    <div>
                      <h5 className="font-semibold text-gray-900 mb-1">{item.name}</h5>
                      <p className="text-gray-600 text-sm">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}