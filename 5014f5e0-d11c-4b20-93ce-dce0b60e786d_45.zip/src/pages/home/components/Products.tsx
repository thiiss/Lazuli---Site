
export default function Products() {
  const products = [
    {
      name: 'Zula',
      description: 'Software modular que elimina a ineficiência na gestão de cronogramas e projetos com IA integrada para análise contextual e assistência conversacional.',
      image: 'https://static.readdy.ai/image/e82d699222721f850528026ac5fab295/97aef0020e7d26db593496f82126b4f2.png',
      features: ['Criação automática de cronogramas', 'Interface visual com Gantt', 'IA para análise contextual', 'Assistência conversacional'],
      color: 'blue',
      link: '/zula'
    },
    {
      name: 'Fira',
      description: 'Sistema de inspeção de qualidade que utiliza visão computacional com duas webcams e Raspberry Pi 4 para detectar defeitos automaticamente.',
      image: 'https://static.readdy.ai/image/e82d699222721f850528026ac5fab295/a27f8962da4c7cb6ae7f23ee445cf09d.png',
      features: ['Duas webcams sincronizadas', 'Raspberry Pi 4', 'Detecção automática de defeitos', 'Relatórios em tempo real'],
      color: 'orange',
      link: '/fira'
    }
  ];

  return (
    <section id="produtos" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Nossos <span className="text-blue-600">Produtos</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Soluções inovadoras que transformam a gestão de projetos e controle de qualidade
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12" data-product-shop>
          {products.map((product, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-shadow duration-300">
              <div className="p-8">
                <div className="flex items-center mb-6">
                  <div className="w-16 h-16 bg-gray-100 rounded-xl flex items-center justify-center p-2 mr-4">
                    <img 
                      src={product.image} 
                      alt={`Logo ${product.name}`}
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div>
                    <h3 className="text-3xl font-bold text-gray-900">{product.name}</h3>
                    <div className={`w-12 h-1 bg-${product.color}-600 rounded-full mt-2`}></div>
                  </div>
                </div>
                
                <p className="text-gray-600 text-lg leading-relaxed mb-6">
                  {product.description}
                </p>
                
                <div className="space-y-3 mb-8">
                  {product.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center">
                      <i className="ri-check-line text-green-500 mr-3"></i>
                      <span className="text-gray-700">{feature}</span>
                    </div>
                  ))}
                </div>
                
                <div className="flex gap-4">
                  <a 
                    href={product.link}
                    className={`flex-1 bg-${product.color}-600 hover:bg-${product.color}-700 text-white text-center py-3 px-6 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer`}
                  >
                    Saiba Mais
                  </a>
                </div>
                
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
