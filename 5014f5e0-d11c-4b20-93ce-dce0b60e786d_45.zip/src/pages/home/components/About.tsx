
import React from 'react';

const About: React.FC = () => {
  return (
    <section id="sobre" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Quem é a <span className="text-blue-600">Lazuli</span>?</h2>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Lado esquerdo - Cards informativos */}
          <div className="grid gap-8">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <i className="ri-lightbulb-line text-2xl text-blue-600"></i>
              </div>
              <div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">Inspiração</h4>
                <p className="text-gray-600 leading-relaxed">
                  Nosso nome deriva da pedra lápis-lazuli, símbolo de sabedoria e verdade. 
                  Assim como esta pedra preciosa revela sua beleza através do polimento, 
                  transformamos processos industriais complexos em soluções elegantes e eficientes.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <i className="ri-compass-3-line text-2xl text-green-600"></i>
              </div>
              <div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">Missão</h4>
                <p className="text-gray-600 leading-relaxed">
                  Democratizar o acesso à automação industrial inteligente, oferecendo soluções 
                  acessíveis que aumentam a produtividade e qualidade dos processos manufatureiros 
                  em empresas de todos os portes.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <i className="ri-heart-line text-2xl text-purple-600"></i>
              </div>
              <div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">Paixão</h4>
                <p className="text-gray-600 leading-relaxed">
                  Acreditamos que a tecnologia deve servir às pessoas. Nossa paixão está em 
                  criar soluções que não apenas automatizam processos, mas empoderam equipes 
                  a alcançar resultados extraordinários.
                </p>
              </div>
            </div>
          </div>

          {/* Lado direito - Imagem e valores */}
          <div className="space-y-6">
            <div className="relative">
              <img 
                src="https://readdy.ai/api/search-image?query=beautiful%20blue%20lapis%20lazuli%20gemstone%20close%20up%20macro%20photography%2C%20deep%20blue%20color%20with%20golden%20veins%2C%20natural%20mineral%20texture%2C%20wisdom%20and%20knowledge%20symbolism%2C%20ancient%20egyptian%20inspiration%2C%20luxury%20and%20elegance&width=500&height=300&seq=lazuli-stone&orientation=landscape"
                alt="Lápis Lazuli - Símbolo de Sabedoria"
                className="w-full h-64 object-cover rounded-xl"
              />
              <div className="absolute bottom-4 left-4 bg-black/70 text-white px-3 py-1 rounded-lg">
                <div className="text-xs">Lápis Lazuli</div>
                <div className="text-sm font-semibold">Símbolo de Sabedoria</div>
              </div>
            </div>
            
            <div className="bg-blue-600 rounded-xl p-6 text-white">
              <h4 className="text-xl font-semibold mb-4">Nossos Valores</h4>
              
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                  <span className="text-sm">Qualidade sem concessões</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                  <span className="text-sm">Soluções completas e robustas</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                  <span className="text-sm">Parceria verdadeira com clientes</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                  <span className="text-sm">Adaptabilidade inteligente</span>
                </div>
              </div>
              
              <div className="mt-6 p-4 bg-blue-700 rounded-lg">
                <p className="text-sm italic text-blue-100 leading-relaxed">
                  "Cada decisão técnica existe para resolver dores específicas e gerar impacto real, qualidade sem concessões, entregando soluções completas, robustas e intuitivas."
                </p>
                <div className="text-xs text-blue-200 mt-2">Filosofia Lazuli</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
