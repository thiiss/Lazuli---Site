
export default function Hero() {
  return (
    <section 
      className="relative min-h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: `linear-gradient(rgba(30, 64, 175, 0.8), rgba(59, 130, 246, 0.6)), url('https://readdy.ai/api/search-image?query=Modern%20industrial%20facility%20with%20advanced%20technology%2C%20artificial%20intelligence%20systems%2C%20computer%20vision%20equipment%2C%20blue%20and%20white%20color%20scheme%2C%20clean%20minimalist%20design%2C%20futuristic%20manufacturing%20environment%2C%20high-tech%20laboratory%20setting%2C%20professional%20lighting%2C%20sleek%20modern%20architecture&width=1920&height=1080&seq=hero-lazuli&orientation=landscape')`
      }}
    >
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            Inovação e <span className="text-blue-300">Eficiência</span> para a Indústria
          </h2>
          <p className="text-xl md:text-2xl mb-8 text-blue-100 leading-relaxed">
            A Lazuli oferece soluções de ponta, unindo <strong>Inteligência Artificial</strong> e <strong>Visão Computacional</strong> para modernizar a gestão de projetos e o controle de qualidade na produção.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="#produtos" className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-blue-50 transition-colors cursor-pointer whitespace-nowrap">
              Conheça Nossos Produtos
            </a>
            <a href="#contato" className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors cursor-pointer whitespace-nowrap">
              Solicitar Demonstração
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
