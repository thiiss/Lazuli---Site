
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToContact = () => {
    const contactSection = document.getElementById('contato');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <a href="/" className="flex items-center">
              <span className="text-2xl font-bold text-gray-900" style={{ fontFamily: '"Pacifico", serif' }}>
                Lazuli
              </span>
            </a>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <a href="#inicio" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">Início</a>
            <a href="#produtos" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">Produtos</a>
            <a href="#tecnologia" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">Tecnologia</a>
            <a href="#sobre" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">Sobre</a>
            <a href="#contato" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">Contato</a>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <button 
              onClick={scrollToContact}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer"
            >
              <i className="ri-phone-line mr-2"></i>
              Fale Conosco
            </button>
          </div>
          
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700 hover:text-blue-600 cursor-pointer"
            >
              <i className={isMenuOpen ? 'ri-close-line text-2xl' : 'ri-menu-line text-2xl'}></i>
            </button>
          </div>
        </div>
        
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-t">
              <a href="/" className="block px-3 py-2 text-gray-700 hover:text-blue-600 cursor-pointer">
                Início
              </a>
              <a href="/zula" className="block px-3 py-2 text-gray-700 hover:text-blue-600 cursor-pointer">
                Zula
              </a>
              <a href="/fira" className="block px-3 py-2 text-gray-700 hover:text-orange-600 cursor-pointer">
                Fira
              </a>
              <a href="#about" className="block px-3 py-2 text-gray-700 hover:text-blue-600 cursor-pointer">
                Sobre
              </a>
              <a href="#contato" className="block px-3 py-2 text-gray-700 hover:text-blue-600 cursor-pointer">
                Contato
              </a>
              <button 
                onClick={scrollToContact}
                className="w-full mt-4 bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer"
              >
                <i className="ri-phone-line mr-2"></i>
                Fale Conosco
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
