
import Header from '../home/components/Header';
import Footer from '../home/components/Footer';
import ZulaHero from './components/ZulaHero';
import ZulaFeatures from './components/ZulaFeatures';
import ZulaTechnology from './components/ZulaTechnology';
import ZulaContact from './components/ZulaContact';

export default function ZulaPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <ZulaHero />
      <ZulaFeatures />
      <ZulaTechnology />
      <ZulaContact />
      <Footer />
    </div>
  );
}
