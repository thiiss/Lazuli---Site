
export default function ZulaSpecs() {
  const specifications = [
    {
      category: 'Requisitos do Sistema',
      items: [
        { label: 'Sistema Operacional', value: 'Windows 10+, macOS 10.15+, Linux Ubuntu 18+' },
        { label: 'Memória RAM', value: 'Mínimo 8GB, Recomendado 16GB' },
        { label: 'Processador', value: 'Intel i5 ou AMD Ryzen 5 (4ª geração ou superior)' },
        { label: 'Armazenamento', value: '10GB de espaço livre' },
        { label: 'Conexão', value: 'Internet banda larga (mínimo 10 Mbps)' }
      ]
    },
    {
      category: 'Capacidades do Sistema',
      items: [
        { label: 'Projetos Simultâneos', value: 'Até 1.000 projetos ativos' },
        { label: 'Usuários Concorrentes', value: 'Até 10.000 usuários' },
        { label: 'Tarefas por Projeto', value: 'Ilimitadas' },
        { label: 'Armazenamento de Dados', value: '1TB por organização' },
        { label: 'Backup Automático', value: 'A cada 15 minutos' }
      ]
    },
    {
      category: 'Recursos de IA',
      items: [
        { label: 'Modelos de ML', value: 'TensorFlow 2.x, PyTorch' },
        { label: 'Processamento NLP', value: 'GPT-4, BERT, Transformer' },
        { label: 'Análise Preditiva', value: 'Precisão de 95% em cronogramas' },
        { label: 'Tempo de Resposta IA', value: 'Menos de 2 segundos' },
        { label: 'Idiomas Suportados', value: 'Português, Inglês, Espanhol' }
      ]
    },
    {
      category: 'Integrações',
      items: [
        { label: 'APIs REST', value: 'Documentação completa OpenAPI 3.0' },
        { label: 'Webhooks', value: 'Eventos em tempo real' },
        { label: 'Microsoft Project', value: 'Importação/Exportação nativa' },
        { label: 'Jira/Confluence', value: 'Sincronização bidirecional' },
        { label: 'Slack/Teams', value: 'Notificações integradas' }
      ]
    }
  ];

  const performance = [
    { metric: 'Tempo de Carregamento', value: '< 3s', icon: 'ri-speed-line', color: 'text-green-600' },
    { metric: 'Disponibilidade', value: '99.9%', icon: 'ri-shield-check-line', color: 'text-blue-600' },
    { metric: 'Precisão da IA', value: '95%', icon: 'ri-brain-line', color: 'text-purple-600' },
    { metric: 'Satisfação do Cliente', value: '4.8/5', icon: 'ri-star-fill', color: 'text-yellow-600' }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Especificações <span className="text-blue-600">Técnicas</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Detalhes técnicos completos para implementação e operação do Zula
          </p>
        </div>

        {/* Performance Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
          {performance.map((item, index) => (
            <div key={index} className="bg-white rounded-xl p-6 text-center shadow-lg">
              <div className={`w-16 h-16 mx-auto mb-4 rounded-full bg-gray-100 flex items-center justify-center`}>
                <i className={`${item.icon} text-2xl ${item.color}`}></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">{item.value}</h3>
              <p className="text-gray-600">{item.metric}</p>
            </div>
          ))}
        </div>

        {/* Detailed Specifications */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {specifications.map((spec, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 shadow-lg">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <i className="ri-settings-3-line text-blue-600 mr-3"></i>
                {spec.category}
              </h3>
              
              <div className="space-y-4">
                {spec.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between items-start py-3 border-b border-gray-100 last:border-b-0">
                    <span className="font-medium text-gray-700 flex-1">{item.label}</span>
                    <span className="text-gray-900 font-semibold text-right flex-1">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Security & Compliance */}
        <div className="mt-16 bg-gradient-to-r from-gray-900 to-gray-800 rounded-2xl p-8 text-white">
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold mb-4">Segurança e Compliance</h3>
            <p className="text-xl text-gray-300">
              Padrões internacionais de segurança e conformidade regulatória
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <i className="ri-shield-check-line text-4xl text-green-400 mb-4"></i>
              <h4 className="text-xl font-bold mb-2">ISO 27001</h4>
              <p className="text-gray-300">Certificação de segurança da informação</p>
            </div>
            <div className="text-center">
              <i className="ri-lock-line text-4xl text-blue-400 mb-4"></i>
              <h4 className="text-xl font-bold mb-2">LGPD/GDPR</h4>
              <p className="text-gray-300">Conformidade com proteção de dados</p>
            </div>
            <div className="text-center">
              <i className="ri-cloud-line text-4xl text-purple-400 mb-4"></i>
              <h4 className="text-xl font-bold mb-2">SOC 2 Type II</h4>
              <p className="text-gray-300">Auditoria de controles de segurança</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
