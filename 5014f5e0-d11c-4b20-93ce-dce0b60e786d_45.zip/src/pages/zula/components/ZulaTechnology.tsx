
export default function ZulaTechnology() {
  const techStack = [
    {
      category: 'Backend & IA',
      technologies: [
        { name: 'Python', description: 'Processamento de dados e algoritmos de IA' },
        { name: 'TensorFlow', description: 'Machine Learning para análise preditiva' },
        { name: 'FastAPI', description: 'APIs de alta performance' },
        { name: 'PostgreSQL', description: 'Banco de dados robusto e escalável' }
      ]
    },
    {
      category: 'Frontend & UX',
      technologies: [
        { name: 'React', description: 'Interface moderna e responsiva' },
        { name: 'TypeScript', description: 'Desenvolvimento type-safe' },
        { name: 'Tailwind CSS', description: 'Design system consistente' },
        { name: 'WebRTC', description: 'Comunicação em tempo real' }
      ]
    },
    {
      category: 'IA & Análise',
      technologies: [
        { name: 'Natural Language Processing', description: 'Processamento de linguagem natural' },
        { name: 'Análise Preditiva', description: 'Previsão de riscos e oportunidades' },
        { name: 'Computer Vision', description: 'Análise visual de documentos' },
        { name: 'Deep Learning', description: 'Aprendizado contínuo do sistema' }
      ]
    },
    {
      category: 'Infraestrutura',
      technologies: [
        { name: 'Docker', description: 'Containerização e deploy' },
        { name: 'Kubernetes', description: 'Orquestração de containers' },
        { name: 'Redis', description: 'Cache de alta performance' },
        { name: 'Elasticsearch', description: 'Busca e análise de dados' }
      ]
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Stack Tecnológico do Zula
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Construído com as mais avançadas tecnologias para garantir performance, escalabilidade e inteligência artificial de ponta.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {techStack.map((stack, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <div className="w-3 h-3 bg-blue-600 rounded-full mr-3"></div>
                {stack.category}
              </h3>
              <div className="space-y-4">
                {stack.technologies.map((tech, techIndex) => (
                  <div key={techIndex} className="flex items-start">
                    <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <div>
                      <div className="font-semibold text-gray-900">{tech.name}</div>
                      <div className="text-gray-600 text-sm">{tech.description}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
            Arquitetura do Sistema
          </h3>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-cloud-fill text-3xl text-blue-600"></i>
              </div>
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Cloud Native</h4>
              <p className="text-gray-600">
                Arquitetura distribuída em nuvem para máxima disponibilidade e escalabilidade.
              </p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-shield-check-fill text-3xl text-green-600"></i>
              </div>
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Segurança Avançada</h4>
              <p className="text-gray-600">
                Criptografia end-to-end e autenticação multi-fator para proteção total dos dados.
              </p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-rocket-fill text-3xl text-purple-600"></i>
              </div>
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Performance</h4>
              <p className="text-gray-600">
                Otimizado para resposta em tempo real com processamento distribuído.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
