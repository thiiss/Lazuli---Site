
export default function ZulaHero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('https://readdy.ai/api/search-image?query=Modern%20project%20management%20software%20interface%20showing%20advanced%20Gantt%20charts%2C%20timeline%20visualization%2C%20task%20management%20dashboard%2C%20AI%20chatbot%20integration%2C%20blue%20and%20white%20professional%20UI%20design%2C%20clean%20minimalist%20layout%2C%20automated%20workflow%20system%2C%20modular%20design%20elements%2C%20artificial%20intelligence%20features%2C%20conversational%20assistant%20interface%2C%20strategic%20insights%20dashboard&width=1920&height=1080&seq=zula-hero-bg&orientation=landscape')`
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-transparent"></div>
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="flex items-center justify-center lg:justify-start">
          <div className="text-white max-w-4xl">
            <div className="flex items-center mb-6">
              <div className="w-20 h-20 bg-white rounded-2xl flex items-center justify-center p-3 mr-6">
                <img 
                  src="https://static.readdy.ai/image/e82d699222721f850528026ac5fab295/97aef0020e7d26db593496f82126b4f2.png" 
                  alt="Logo Zula"
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <h1 className="text-5xl font-bold mb-2">Zula</h1>
                <p className="text-2xl text-blue-300">Gestão de Cronogramas com IA</p>
              </div>
            </div>
            
            <p className="text-xl leading-relaxed mb-8 max-w-3xl">
              Software modular revolucionário que elimina a ineficiência na gestão de cronogramas e projetos. 
              Automatiza e simplifica todo o ciclo de vida do projeto com <strong>Inteligência Artificial integrada</strong> 
              e assistência conversacional inteligente.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
