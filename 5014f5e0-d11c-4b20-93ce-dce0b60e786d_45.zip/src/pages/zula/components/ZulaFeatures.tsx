
export default function ZulaFeatures() {
  const features = [
    {
      icon: 'ri-calendar-schedule-fill',
      title: 'Gestão Inteligente de Cronogramas',
      description: 'Crie, monitore e ajuste cronogramas automaticamente com base em dados históricos e padrões de produtividade da equipe.'
    },
    {
      icon: 'ri-robot-2-fill',
      title: 'IA Integrada para Análise Contextual',
      description: 'Sistema de inteligência artificial que analisa contexto dos projetos, identifica riscos e sugere otimizações em tempo real.'
    },
    {
      icon: 'ri-team-fill',
      title: 'Colaboração em Tempo Real',
      description: 'Facilite a comunicação entre equipes com atualizações instantâneas, comentários contextuais e notificações inteligentes.'
    },
    {
      icon: 'ri-chat-voice-fill',
      title: 'Assistência Conversacional',
      description: 'Interaja com o sistema através de comandos de voz e chat, obtendo relatórios e atualizações de forma natural e intuitiva.'
    },
    {
      icon: 'ri-dashboard-3-fill',
      title: 'Dashboards Personalizáveis',
      description: 'Visualize métricas importantes através de painéis customizáveis que se adaptam às necessidades específicas do seu projeto.'
    },
    {
      icon: 'ri-notification-3-fill',
      title: 'Alertas Preditivos',
      description: 'Receba notificações antecipadas sobre possíveis atrasos, conflitos de recursos e oportunidades de otimização.'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Recursos Avançados do Zula
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Descubra como nossa plataforma revoluciona a gestão de projetos através de tecnologia de ponta e inteligência artificial.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-gradient-to-br from-blue-50 to-indigo-100 rounded-xl p-8 hover:shadow-lg transition-shadow duration-300">
              <div className="w-16 h-16 bg-blue-600 rounded-lg flex items-center justify-center mb-6">
                <i className={`${feature.icon} text-2xl text-white`}></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
